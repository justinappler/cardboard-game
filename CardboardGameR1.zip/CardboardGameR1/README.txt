To play the Cardboard Game, either:

   1. Double-click on the file named CardBoardApp_R1.jar
   2. Double-click on run_cardboardapp.bat on Windows
   3. Execute run_cardboardapp.sh on Unix/OSX