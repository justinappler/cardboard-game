#!/bin/bash
java -jar CardBoardApp_R1.jar